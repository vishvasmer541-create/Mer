create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  price_inr integer not null check (price_inr > 0),
  license text not null,
  storage_key text not null unique,
  file_name text not null,
  file_format text not null check (file_format in ('3dm','stl')),
  preview_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  customer_email text not null,
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR',
  razorpay_order_id text not null unique,
  razorpay_payment_id text unique,
  payment_status text not null default 'created' check (payment_status in ('created','paid','failed')),
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.webhook_events (
  event_id text primary key,
  event_type text not null,
  received_at timestamptz not null default now()
);

create table if not exists public.download_logs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.webhook_events enable row level security;
alter table public.download_logs enable row level security;

-- No public policies are defined here. Browser clients cannot directly read or mutate these tables.
-- Public product catalogue should be served through a carefully scoped server API/view.
-- Never expose SUPABASE_SERVICE_ROLE_KEY in browser code.
