# Production readiness checklist

## Accounts and settings
- [ ] Register / sign in to Razorpay and complete its business verification requirements.
- [ ] Create Test Mode keys first; do not paste secrets into chat or Git.
- [ ] Create private Cloudflare R2 bucket; do not enable public access.
- [ ] Create a Supabase project and run `supabase/schema.sql`.
- [ ] Create a dedicated admin user, then assign `app_metadata.role = "admin"` only from a trusted server/admin process.
- [ ] Add environment variables in local `.env.local` and Vercel project settings.

## Payment safety
- [ ] Create Razorpay orders on server only; product price comes from database.
- [ ] Webhook URL uses HTTPS and raw body signature validation.
- [ ] Subscribe to `payment.captured` and `payment.failed`.
- [ ] Test wrong signature, duplicate webhook, amount mismatch, failed payment, abandoned checkout, and delayed webhook.
- [ ] Reconcile webhook payload with Razorpay payment/order API before launch as an extra defense.
- [ ] Keep download locked until a matching captured payment with matching amount/currency/order ID is confirmed.
- [ ] Add a transactional database function so event recording and order update cannot get out of sync. Current sample uses separate statements and needs hardening.

## File protection
- [ ] Keep all master 3DM/STL files in a private R2 bucket.
- [ ] Only trusted admin can upload. Validate file signature/content where possible, not just extension.
- [ ] Add per-order download count/limits and rate limiting.
- [ ] Add customer order lookup that uses an email verification link or authenticated account; do not rely on order UUID + email alone for high-value files.
- [ ] Ensure signed URL expiry is short; signed URLs can be shared until expiry.
- [ ] Add file backups and test restore.

## Business launch
- [ ] Add product previews, exact file format/version, dimensions, licence/usage rights, and refund policy.
- [ ] Add privacy policy, terms, contact details, and relevant Indian tax/invoice handling after professional review.
- [ ] Configure domain and HTTPS.
- [ ] Test on Android phone and desktop.
- [ ] Complete end-to-end test purchase in Razorpay Test Mode.
- [ ] Only switch to Live Mode after security review and a successful test checklist.
