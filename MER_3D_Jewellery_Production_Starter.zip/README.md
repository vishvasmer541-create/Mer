# MER 3D Jewellery Files — production starter

This is a **starter codebase**, not a live store. It does not create accounts, configure Razorpay, deploy hosting, or verify that your business account is approved.

## Recommended stack
- Next.js (App Router) on Vercel
- Supabase Postgres for products/orders/webhook event deduplication
- Cloudflare R2 private bucket for paid `.3dm` / `.stl` files
- Razorpay Orders API + verified webhook

## Setup overview
1. Create accounts yourself at Vercel, Supabase, Cloudflare and Razorpay.
2. Create a Supabase project. Run `supabase/schema.sql` in its SQL editor.
3. Create a **private** R2 bucket and an API token with only the required bucket permissions.
4. In Razorpay, start with Test Mode; create a webhook endpoint at `https://YOUR_DOMAIN/api/razorpay/webhook`. Subscribe to `payment.captured` and `payment.failed`. Copy the webhook secret.
5. Copy `.env.example` to `.env.local` and fill values locally. Never commit `.env.local`.
6. Install Node.js 20+ and run:
   ```bash
   npm install
   npm run dev
   ```
7. Deploy via Vercel after pushing this project to a private Git repository. Set the same environment variables in Vercel.
8. Configure Razorpay's webhook URL to the deployed domain, then test in Test Mode before enabling Live Mode.

## Important gaps before real sales
This starter deliberately does not include a complete storefront, customer account UI, production admin UI, tax/invoice logic, refunds, customer support flow, rate limiting, or automated tests. The Admin API route expects Supabase Auth and an `app_metadata.role = "admin"` claim; create and verify admin users securely before use. Add abuse protection and review all code before accepting real payments.

## File upload approach
Upload `.3dm` / `.stl` files from a trusted server/admin process to private R2; never store files in the public `/public` folder. The included upload endpoint requires an authenticated Supabase user with admin role and enforces extensions/size. Test it with files you own.

## Security behavior
- Price comes from the database, never from the browser.
- Razorpay order is created server-side.
- Payment callback signature is verified server-side.
- Webhook uses the raw request body and HMAC signature.
- Webhook events are deduplicated by event ID.
- Download endpoint checks a paid order before issuing a short-lived R2 URL.
- R2 bucket stays private.

This is a developer starter, not legal, tax, payment-provider or security advice.
