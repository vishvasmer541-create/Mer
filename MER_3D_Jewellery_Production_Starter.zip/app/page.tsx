export default function Home() {
  return <main className="wrap">
    <header><div className="brand">MER <span>3D Jewellery Files</span></div><div className="tag">Digital downloads · 3DM · STL</div></header>
    <section className="hero">
      <p className="eyebrow">DIGITAL JEWELLERY DESIGN LIBRARY</p>
      <h1>Jewellery files.<br/><em>Ready for your workflow.</em></h1>
      <p className="intro">Browse 3DM and STL design files for jewellery CAD workflows. Secure checkout and downloads become available after the payment system is configured and tested.</p>
      <div className="notice">Starter template — demo catalogue is not connected to a live database or payment account yet.</div>
    </section>
    <section className="steps">
      <article><b>01</b><h2>Choose a design</h2><p>Product page should show previews, included formats, licence and price.</p></article>
      <article><b>02</b><h2>Pay securely</h2><p>Razorpay checkout is created by the server; price is read from the database.</p></article>
      <article><b>03</b><h2>Download</h2><p>After verified payment, a short-lived private download link can be issued.</p></article>
    </section>
    <footer>MER · Digital design files only · Please check each file’s licence before use.</footer>
  </main>;
}
