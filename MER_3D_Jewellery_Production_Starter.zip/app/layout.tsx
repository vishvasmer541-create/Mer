import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "MER 3D Jewellery Files",
  description: "Downloadable 3DM and STL jewellery design files",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
