import { NextResponse } from "next/server";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { r2Client } from "@/lib/r2";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const { orderId, email } = await req.json();
    if (typeof orderId !== "string" || typeof email !== "string") {
      return NextResponse.json({ error: "Order ID and email required" }, { status: 400 });
    }
    const db = supabaseAdmin();
    const { data: order } = await db.from("orders")
      .select("id,customer_email,payment_status,product_id")
      .eq("id", orderId).eq("customer_email", email.toLowerCase()).single();
    if (!order || order.payment_status !== "paid") {
      return NextResponse.json({ error: "Paid order not found" }, { status: 403 });
    }
    const { data: product } = await db.from("products").select("storage_key,file_name")
      .eq("id", order.product_id).single();
    if (!product?.storage_key) return NextResponse.json({ error: "File not available" }, { status: 404 });

    const bucket = process.env.R2_BUCKET_NAME;
    if (!bucket) throw new Error("Missing R2 bucket");
    const command = new GetObjectCommand({
      Bucket: bucket, Key: product.storage_key,
      ResponseContentDisposition: `attachment; filename="${String(product.file_name || "jewellery-file").replace(/[^a-zA-Z0-9._-]/g, "_")}"`
    });
    const url = await getSignedUrl(r2Client(), command, { expiresIn: 120 });
    await db.from("download_logs").insert({ order_id: order.id, created_at: new Date().toISOString() });
    return NextResponse.json({ downloadUrl: url, expiresInSeconds: 120 });
  } catch {
    return NextResponse.json({ error: "Could not create download link" }, { status: 500 });
  }
}
