import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { razorpayClient } from "@/lib/razorpay";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const { productId, customerEmail } = await req.json();
    if (typeof productId !== "string" || typeof customerEmail !== "string" ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail)) {
      return NextResponse.json({ error: "Valid productId and email are required" }, { status: 400 });
    }
    const db = supabaseAdmin();
    const { data: product, error } = await db.from("products")
      .select("id,title,price_inr,is_active,storage_key").eq("id", productId).eq("is_active", true).single();
    if (error || !product) return NextResponse.json({ error: "Product not found" }, { status: 404 });
    if (!Number.isInteger(product.price_inr) || product.price_inr < 1) {
      return NextResponse.json({ error: "Invalid product price" }, { status: 500 });
    }

    const rp = razorpayClient();
    const order = await rp.orders.create({
      amount: product.price_inr * 100,
      currency: "INR",
      receipt: `mer_${cryptoRandomId()}`,
      notes: { product_id: product.id, customer_email: customerEmail }
    });
    const { error: insertError } = await db.from("orders").insert({
      product_id: product.id, customer_email: customerEmail, amount_paise: product.price_inr * 100,
      currency: "INR", razorpay_order_id: order.id, payment_status: "created"
    });
    if (insertError) return NextResponse.json({ error: "Could not record order" }, { status: 500 });
    return NextResponse.json({ keyId: process.env.RAZORPAY_KEY_ID, orderId: order.id,
      amount: order.amount, currency: order.currency, productTitle: product.title });
  } catch {
    return NextResponse.json({ error: "Checkout could not be created" }, { status: 500 });
  }
}
function cryptoRandomId() { return crypto.randomUUID().replace(/-/g, "").slice(0, 18); }
import crypto from "node:crypto";
