import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { hmacHex, safeEqualHex } from "@/lib/signatures";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: "Webhook is not configured" }, { status: 500 });

  const rawBody = await req.text();
  const signature = req.headers.get("x-razorpay-signature") || "";
  const expected = hmacHex(secret, rawBody);
  if (!safeEqualHex(signature, expected)) {
    return NextResponse.json({ error: "Invalid webhook signature" }, { status: 400 });
  }

  try {
    const event = JSON.parse(rawBody);
    const eventId = req.headers.get("x-razorpay-event-id");
    if (!eventId) return NextResponse.json({ error: "Missing event ID" }, { status: 400 });

    const db = supabaseAdmin();
    const { error: eventInsertError } = await db.from("webhook_events").insert({
      event_id: eventId, event_type: event.event, received_at: new Date().toISOString()
    });
    if (eventInsertError) {
      // Unique event_id: already processed; return 200 to stop endless retries.
      return NextResponse.json({ received: true, duplicate: true });
    }

    if (event.event === "payment.captured") {
      const payment = event.payload?.payment?.entity;
      if (!payment?.order_id || !payment?.id || payment.status !== "captured") {
        return NextResponse.json({ error: "Unexpected payment payload" }, { status: 400 });
      }
      const { data: order } = await db.from("orders").select("id,amount_paise,currency")
        .eq("razorpay_order_id", payment.order_id).single();
      if (order && Number(payment.amount) === order.amount_paise && payment.currency === order.currency) {
        await db.from("orders").update({
          payment_status: "paid", razorpay_payment_id: payment.id, paid_at: new Date().toISOString()
        }).eq("id", order.id);
      }
    } else if (event.event === "payment.failed") {
      const payment = event.payload?.payment?.entity;
      if (payment?.order_id) {
        await db.from("orders").update({ payment_status: "failed" })
          .eq("razorpay_order_id", payment.order_id).neq("payment_status", "paid");
      }
    }
    return NextResponse.json({ received: true });
  } catch {
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 });
  }
}
