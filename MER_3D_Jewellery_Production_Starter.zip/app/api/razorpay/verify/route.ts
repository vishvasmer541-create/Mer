import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { safeEqualHex } from "@/lib/signatures";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();
    if (![razorpay_order_id, razorpay_payment_id, razorpay_signature].every(v => typeof v === "string")) {
      return NextResponse.json({ error: "Invalid payment verification data" }, { status: 400 });
    }
    const secret = process.env.RAZORPAY_KEY_SECRET;
    if (!secret) throw new Error("Missing Razorpay secret");
    const expected = crypto.createHmac("sha256", secret)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
    if (!safeEqualHex(razorpay_signature, expected)) {
      return NextResponse.json({ error: "Payment signature invalid" }, { status: 400 });
    }
    // Signature proves callback integrity, but webhook/API status confirms captured payment.
    const db = supabaseAdmin();
    const { data: order } = await db.from("orders").select("id,razorpay_order_id")
      .eq("razorpay_order_id", razorpay_order_id).single();
    if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
    return NextResponse.json({ received: true, message: "Signature valid. Download remains locked until captured payment is confirmed." });
  } catch {
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
