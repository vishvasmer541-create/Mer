import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import { r2Client } from "@/lib/r2";
import { supabaseAdmin } from "@/lib/supabase-admin";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) return NextResponse.json({ error: "Admin login required" }, { status: 401 });
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false, autoRefreshToken: false }
    });
    const { data: { user }, error } = await userClient.auth.getUser();
    if (error || !user || user.app_metadata?.role !== "admin") {
      return NextResponse.json({ error: "Admin access denied" }, { status: 403 });
    }

    const form = await req.formData();
    const file = form.get("file");
    const title = String(form.get("title") || "").trim();
    const price = Number(form.get("priceInr"));
    const license = String(form.get("license") || "").trim();
    if (!(file instanceof File) || !title || !Number.isInteger(price) || price < 1 || !license) {
      return NextResponse.json({ error: "File, title, integer INR price and licence are required" }, { status: 400 });
    }
    const ext = file.name.toLowerCase().split(".").pop();
    if (!["3dm", "stl"].includes(ext || "")) return NextResponse.json({ error: "Only .3dm and .stl files allowed" }, { status: 400 });
    const maxBytes = 100 * 1024 * 1024;
    if (file.size < 1 || file.size > maxBytes) return NextResponse.json({ error: "File must be under 100 MB" }, { status: 400 });

    const key = `products/${crypto.randomUUID()}.${ext}`;
    const bucket = process.env.R2_BUCKET_NAME;
    if (!bucket) throw new Error("Missing bucket");
    await r2Client().send(new PutObjectCommand({
      Bucket: bucket, Key: key, Body: Buffer.from(await file.arrayBuffer()),
      ContentType: "application/octet-stream"
    }));
    const db = supabaseAdmin();
    const { data, error: dbError } = await db.from("products").insert({
      title, price_inr: price, license, storage_key: key, file_name: file.name,
      file_format: ext, is_active: true
    }).select("id,title,price_inr,file_format").single();
    if (dbError) return NextResponse.json({ error: "File uploaded but product record failed; remove orphaned file from R2" }, { status: 500 });
    return NextResponse.json({ product: data }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }
}
import crypto from "node:crypto";
